+++
date = "2014-07-11T10:54:24+02:00"
draft = false
title = "Post title"
slug = "post-title"
tags = ["tag1","tag2"]
image = ""
comments = true	# set false to hide Disqus
share = true	# set false to hide share buttons
menu= ""		# set "main" to add this content to the main menu
author = ""
+++